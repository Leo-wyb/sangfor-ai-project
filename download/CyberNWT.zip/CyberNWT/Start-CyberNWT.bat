@echo off
setlocal
title CyberNWT Server
cd /d "%~dp0app"

echo ============================================
echo     CyberNWT starting...
echo     The login page will open in your browser.
echo     Keep this window OPEN. Closing it stops the service.
echo ============================================
echo.

set "PY="
where python >nul 2>nul && set "PY=python"
if not defined PY ( where py >nul 2>nul && set "PY=py" )

if not defined PY (
    echo [ERROR] Python not found.
    echo This product needs only Python 3 standard library.
    echo Please install Python 3 first:
    echo     https://www.python.org/downloads/
    echo Remember to check "Add Python to PATH" during install.
    echo.
    pause
    exit /b 1
)

echo Interpreter: %PY%
echo Address: http://127.0.0.1:8642
echo Account: admin / admin
echo.
echo ------------------------------------------------------------
echo Keep this window open. Close it to stop the server.
echo ------------------------------------------------------------
echo.

%PY% server.py

echo.
echo Server stopped. Press any key to close...
pause >nul
